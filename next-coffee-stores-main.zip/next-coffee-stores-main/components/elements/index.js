import Banner from "./banner";
import Heading from "./heading";
import Card from "./card";
import Loader from "./loader";
export { Banner, Heading, Card, Loader };
