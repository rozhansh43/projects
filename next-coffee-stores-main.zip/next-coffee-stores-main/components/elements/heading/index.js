import React from "react";

export default function Heading(props) {
  return <h1 className="text-white font-bold text-[30px] leading-9 mb-8">{props.title}</h1>;
}
