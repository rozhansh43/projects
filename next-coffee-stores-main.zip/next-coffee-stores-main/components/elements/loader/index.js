import React from "react";

export default function Loader() {
  return <h1 className="text-white font-bold text-[30px] leading-9 my-5">loading ...</h1>;
}
