export const QuestionBank = [
    [
        { Question: "1 - 2 = ?", A: "-2", B: "-1", answer: "B" },
        { Question: "True || False = ?", A: "True", B: "False", answer: "A" },
        { Question: "3 + 7 = ?", A: "10", B: "5", answer: "A" },
        { Question: "10 * 3 = ?", A: "30", B: "3", answer: "A" },
        { Question: "20 - 4 = ?", A: "24", B: "16", answer: "B" },
        { Question: "True & False = ?", A: "True", B: "False", answer: "B" },]
    ,
    [
        { Question: "1 - 2 = ?", A: "-2", B: "-1", answer: "B" },
        { Question: "True || False = ?", A: "True", B: "False", answer: "A" },
        { Question: "3 + 7 = ?", A: "10", B: "5", answer: "A" },
        { Question: "10 * 3 = ?", A: "30", B: "3", answer: "A" },
        { Question: "20 - 4 = ?", A: "24", B: "16", answer: "B" },
        { Question: "True & False = ?", A: "True", B: "False", answer: "B" },
    ]


]