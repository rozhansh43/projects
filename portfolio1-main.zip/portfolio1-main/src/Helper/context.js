import {CreateContext,useContext} from 'react'
const context=CreateContext()
 const contextProvider =({children})=>{

 }