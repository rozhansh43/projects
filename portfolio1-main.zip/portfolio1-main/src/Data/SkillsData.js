const SkillData = [
    {
        title: "HTML",
        width: "80%"
    },
    {
        title: "CSS",
        width: "85%"
    },
    {
        title: "SCSS",
        width: "85%"
    },
    {
        title: "JavaScript",
        width: "70%"
    },
    {
        title: "React JS",
        width: "50%"
    },
    {
        title: "Next JS",
        width: "50%"
    },
    {
        title: "Typescript",
        width: "50%"
    },
    {
        title: "BootStrap",
        width: "60%"
    },
    {
        title: "Tailwind",
        width: "80%"
    },
    {
        title: "Material UI",
        width: "40%"
    },
    {
        title: "StyledComponents",
        width: "50%"
    },
    {
        title: "ReactQuery",
        width: "50%"
    },
    {
        title: "Redux Toolkit",
        width: "50%"
    },
    {
        title: "ReactHookForm",
        width: "50%"
    },
]
export default SkillData
