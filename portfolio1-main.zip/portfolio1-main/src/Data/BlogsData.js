import blog1 from '../Images/blogs/blog1.svg'
import blog2 from '../Images/blogs/blog2.svg'
import blog3 from '../Images/blogs/blog3.svg'
import blog4 from '../Images/blogs/blog4.svg'


const blogsData = [
    {
        id: 1, title: "how to write truly", date: "01", month: "April", image: blog1, link: 'https://www.coinex.com/'
    },
    {
        id: 2, title: "how to say good truly", date: "01", month: "Jun", image: blog2, link: 'https://www.coinex.com/'
    },
    {
        id: 3, title: "how to eat food ", date: "11", month: "April", image: blog3, link: 'https://www.coinex.com/'
    },
    {
        id: 4, title: "how buy car efficiently", date: "01", month: "Mey", image: blog4, link: 'https://www.coinex.com/'
    },
]
export default blogsData